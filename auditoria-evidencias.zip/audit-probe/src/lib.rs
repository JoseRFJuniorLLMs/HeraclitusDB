#[path = "D:/DEV/HeraclitusDB/crates/heraclitus-server/src/trusted_admin.rs"]
pub mod trusted_admin;

#[cfg(test)]
mod diagnostics {
    use heraclitus_crypto::*;
    use heraclitus_forensic::*;
    use super::trusted_admin::*;

    // These assertions demonstrate the present defects; they are not safety gates.
    #[test]
    fn envelope_accepts_modified_tenant_key_epoch_and_algorithm() {
        let key = [7; 32];
        let mut env = EncryptionEnvelopeV2::seal(&key, b"private", b"aad", TenantId::new("t1".into()).unwrap(), "key-1".into(), 1);
        env[5] = b'2'; // tenant t1 -> t2
        env[8] = b'X'; // key-1 -> Xey-1
        env[20] = 2; // epoch 1 -> 2
        env[23] = b'X'; // algorithm text
        let header = EncryptionEnvelopeV2::peek_header(&env).unwrap();
        assert_eq!(header.tenant.as_str(), "t2");
        assert_eq!(header.key_epoch, 2);
        assert!(header.algorithm.starts_with('X'));
        assert_eq!(EncryptionEnvelopeV2::open(&key, &env, b"aad").unwrap(), b"private");
    }

    #[test]
    fn rotation_loses_historical_key() {
        let p = SoftwareKeyProvider::new();
        let t = TenantId::new("tenant".into()).unwrap();
        let old = p.wrap_data_key(&t, &[9;32]).unwrap();
        assert_eq!(p.unwrap_data_key(&old).unwrap(), [9;32]);
        p.rotate(&t).unwrap();
        assert!(p.unwrap_data_key(&old).is_err());
    }

    #[test]
    fn destroying_stale_key_destroys_current_epoch() {
        let p = SoftwareKeyProvider::new();
        let t = TenantId::new("tenant".into()).unwrap();
        let old = p.wrap_data_key(&t, &[9;32]).unwrap();
        p.rotate(&t).unwrap();
        let current = p.wrap_data_key(&t, &[8;32]).unwrap();
        assert_eq!(p.unwrap_data_key(&current).unwrap(), [8;32]);
        p.destroy(&old.key_ref).unwrap();
        assert!(p.unwrap_data_key(&current).is_err());
    }

    fn manifest() -> EvidenceManifest {
        serde_json::from_value(serde_json::json!({
            "schema_version":"1.0", "package_id":"p", "case_id":"c", "tenant_id":"t",
            "source_database_id":"d", "source_build":"b", "lsn_range":{"min_lsn":0,"max_lsn":0},
            "hlc_range":{"min_hlc":0,"max_hlc":0}, "objects":[],
            "merkle":{"root_blake3":"", "root_sha256":"invalid", "leaves_count":999},
            "custody_digest":"", "export_identity":"x", "export_reason":"r", "created_at_claimed":0,
            "trusted_timestamps":[{"authority":"invented", "timestamp_secs":0, "token":"invalid"}],
            "signatures":[{"signer_identity":"invented", "signature_hex":"invalid", "algorithm":"invalid"}]
        })).unwrap()
    }

    #[test]
    fn forensic_accepts_invalid_signature_timestamp_and_proofs() {
        let dir = tempfile::tempdir().unwrap();
        let mut b = EvidencePackageBuilder::new(manifest());
        b.set_proofs(serde_json::json!({"invalid":"not a Merkle proof"}));
        b.build(dir.path()).unwrap();
        std::fs::write(dir.path().join("proofs/merkle.json"), b"not even json").unwrap();
        assert!(EvidenceVerifier::new(dir.path()).verify().is_ok());
        std::fs::remove_file(dir.path().join("manifest.sha256")).unwrap();
        assert!(EvidenceVerifier::new(dir.path()).verify().is_ok());
    }

    #[test]
    fn custody_hash_omits_terminal_and_chain_accepts_second_genesis() {
        let mut first = CustodyEntry { step_index:0, timestamp_secs:1, action:CustodyAction::Coleta,
            operator_principal:"alice".into(), terminal_or_node:"original".into(), previous_entry_hash:"".into(), entry_hash:"".into() };
        let original_hash = first.compute_hash();
        first.terminal_or_node = "forged".into();
        assert_eq!(first.compute_hash(), original_hash);
        first.entry_hash = original_hash;
        let mut second = first.clone();
        second.timestamp_secs = 2;
        second.previous_entry_hash = "unrelated".into();
        second.entry_hash = second.compute_hash();
        let dir = tempfile::tempdir().unwrap();
        let mut b = EvidencePackageBuilder::new(manifest());
        b.add_custody_entry(first); b.add_custody_entry(second);
        b.build(dir.path()).unwrap();
        assert!(EvidenceVerifier::new(dir.path()).verify().is_ok());
    }

    #[test]
    fn admin_digest_omits_parameters_and_accepts_unprivileged_context() {
        let p = TrustedAdminProtocol::new();
        let ctx = AdminContext::new("reader", "tenant", vec!["reader".into()]);
        let mut op = AdminOperation::new("op", "idem", AdminOperationKind::KeyDestruction {key_id:"k".into()}, "reason");
        op.parameters_digest = "one".into();
        let hash = op.compute_intent_digest(&ctx);
        op.parameters_digest = "two".into();
        assert_eq!(hash, op.compute_intent_digest(&ctx));
        assert!(p.validate(&ctx, &op).is_ok());
        let token = p.create_execution_token("op".into(), 999);
        assert_eq!(token.intent_lsn(), 999);
        assert_eq!(p.get_operation_state("idem"), None);
        assert_eq!(p.get_operation_state("op"), Some(AdminState::IntentDurable));
    }
}
